# Promise API Documentation

**📍 This documentation has moved!**

The Promise API documentation is now maintained at:
**https://mariadb.com/docs/connectors/mariadb-connector-nodejs/connector-nodejs-promise-api**

Please update your bookmarks and visit the new location for the most up-to-date documentation.

---
*This file is kept for backward compatibility. Last updated: 27/06/2025*
