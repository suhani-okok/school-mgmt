# Connector/Node.js Batch API

**📍 This documentation has moved!**

The Batch API documentation is now maintained at:
**https://mariadb.com/docs/connectors/mariadb-connector-nodejs/connector-nodejs-batch-api**

Please update your bookmarks and visit the new location for the most up-to-date documentation.

---
*This file is kept for backward compatibility. Last updated: 27/06/2025*
